#include <iostream>
#include <vector>

struct Student {
  std::string ime, prezime;
  int brojIndexa;
};

bool istoImePrezime(std::vector<Student> v) {
  for (int i = 0; i < v.size() - 1; i++) {
    for (int j = i + 1; j < v.size(); j++) {
      if (v[i].ime == v[j].ime && v[i].prezime == v[j].prezime)
        return true;
    }
  }
  return false;
}

int main() {
  Student s1, s2, s3;
  s1.ime = "Kerim";
  s1.prezime = "Halilovic";
  s2.ime = "Kemal";
  s2.prezime = "Halilovic";
  s3.ime = "Kerim";
  s3.prezime = "Hodzic";
  std::vector<Student> v{s1, s2, s3};
  std::cout << istoImePrezime(v);
}