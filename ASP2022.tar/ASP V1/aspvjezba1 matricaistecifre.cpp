#include <algorithm>
#include <iostream>
#include <vector>

bool obrnuta(std::vector<std::vector<std::vector<int>>> &vm) {
  std::vector<std::vector<int>> p;
  bool nalazi = false;
  for (int i = 0; i < vm.size(); i++) {
    std::vector<int> x{};
    for (int j = 0; j < vm[i].size(); j++) {
      for (int k = 0; k < vm[i][j].size(); k++) {
        int broj = vm[i][j][k];
        while (broj != 0) {
          int c = broj % 10;
          for (int l = 0; l < x.size(); l++) {
            if (x[l] == c) {
              nalazi = true;
            }
          }
          if (nalazi == false)
            x.push_back(c);
          nalazi = false;
          broj /= 10;
        }
      }
    }
    p.push_back(x);
  }
  for (int i = 0; i < p.size(); i++) {
    sort(p[i].begin(), p[i].end());
  }
  for (int i = 0; i < p.size() - 1; i++) {
    for (int j = i + 1; j < p[i].size(); j++) {
      if (p[i] == p[j])
        return true;
    }
  }
  return false;
}

int main() {
  std::vector<std::vector<int>> v1{
      {15, 3, 25}, {311, 121, 2}, {5, 21, 3112113}},
      v2{{21, 951, 355}, {15, 3, 25}, {1, 22, 55355}}, v3{{99}, {44}, {77}};
  std::vector<std::vector<std::vector<int>>> v{v1, v2, v3};
  std::cout << obrnuta(v);
}