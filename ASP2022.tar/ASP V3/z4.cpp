#include <iostream>
#include <string>

using namespace std;

template <typename Tip> class Stek {
  Tip *stek;
  int kapacitet, top;

public:
  Stek() : kapacitet(100), top(-1) { stek = new Tip[kapacitet]; }
  ~Stek() { delete[] stek; }
  Stek(const Stek &s) : kapacitet(s.kapacitet), top(s.top) {
    stek = new Tip[kapacitet];
    for (int i = 0; i <= top; i++)
      stek[i] = s.stek[i];
  }
  Stek &operator=(const Stek &s) {
    if (this == &s)
      return *this;
    delete[] stek;
    kapacitet = s.kapacitet;
    top = s.top;
    stek = new Tip[kapacitet];
    for (int i = 0; i <= top; i++) {
      stek[i] = s.stek[i];
    }
    return *this;
  }
  void brisi() { top = -1; }
  void stavi(const Tip &el) {
    if (brojElemenata() == kapacitet) {
      kapacitet *= 2;
      Tip *t = stek;
      stek = new Tip[kapacitet];
      for (int i = 0; i < brojElemenata(); i++)
        stek[i] = t[i];
      delete[] t;
    }
    stek[++top] = el;
  }
  Tip skini() {
    if (top == -1)
      throw "Stek je prazan!";
    return stek[top--];
  }
  Tip &vrh() {
    if (top == -1)
      throw "Stek je prazan!";
    return stek[top];
  }
  int brojElemenata() { return top + 1; }
};

void test1() { // test konstruktora bez parametara, metode stavi() i metode
               // brojElemenata()
  Stek<int> s;
  for (int i = 1; i <= 3; i++)
    s.stavi(i);
  std::cout << "Broj elemenata: " << s.brojElemenata();
}

void test2() { // test metode skini()
  Stek<int> s;
  for (int i = 1; i <= 3; i++)
    s.stavi(i);
  s.skini();
  std::cout << "\nBroj elemenata nakon skidanja zadnjeg elementa: "
            << s.brojElemenata();
}

void test3() { // test metode vrh()
  Stek<int> s;
  for (int i = 1; i <= 3; i++)
    s.stavi(i);
  s.skini();
  std::cout << "\nNovi element na vrhu: " << s.vrh();
}

void test4() { // test metode brisi()
  Stek<int> s;
  for (int i = 1; i <= 3; i++)
    s.stavi(i);
  s.brisi();
  std::cout << "\nBroj elemenata nakon brisanja steka: " << s.brojElemenata();
}

void test5() { // test operatora dodjele
  Stek<int> s;
  for (int i = 1; i <= 3; i++)
    s.stavi(i);
  Stek<int> temp1 = s;
  std::cout << "\nBroj elemenata novog steka: " << temp1.brojElemenata();
}

void test6() { // test konstruktora kopije
  Stek<int> s;
  for (int i = 1; i <= 3; i++)
    s.stavi(i);
  Stek<int> temp1(s);
  std::cout << "\nBroj elemenata novog steka: " << temp1.brojElemenata();
}

int spoji(Stek<int> s1, Stek<int> s2, Stek<int> &s3) {
  int ns2 = s2.brojElemenata();
  for (int i = 0; i < ns2; i++) {
    s3.stavi(s2.vrh());
    s2.skini();
  }
  s2 = s3;
  s3.brisi();
  while (s1.brojElemenata() != 0 || s2.brojElemenata() != 0) {
    if (s2.brojElemenata() == 0 || s1.vrh() > s2.vrh()) {
      s3.stavi(s1.vrh());
      s1.skini();
    } else if (s1.brojElemenata() == 0 || s2.vrh() > s1.vrh()) {
      s3.stavi(s2.vrh());
      s2.skini();
    } else {
      s3.stavi(s2.vrh());
      s1.skini();
      s2.skini();
    }
  }
  return 1;
}

int main() {
  Stek<int> s1;
  s1.stavi(1);
  s1.stavi(3);
  s1.stavi(5);
  s1.stavi(8);
  Stek<int> s2;
  s2.stavi(9);
  s2.stavi(6);
  s2.stavi(4);
  s2.stavi(2);
  Stek<int> s3;
  std::cout << spoji(s1, s2, s3) << "\n";
  int n = s3.brojElemenata();
  for (int i = 0; i < n; i++) {
    std::cout << s3.vrh();
    s3.skini();
  }
  return 0;
}