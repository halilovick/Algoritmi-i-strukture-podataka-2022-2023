#include <cmath>
#include <ctime>
#include <iostream>
bool provjera_prost(int n) {
  for (int i = 2; i <= std::sqrt(n); i++) {
    if (n % i == 0)
      return false;
  }
  return true;
}
void Goldbach(int n, int &p, int &q) {
  if (n <= 2)
    throw std::logic_error("Rastava ne postoji");
  for (int i = 2; i < n; i++) {
    if (provjera_prost(i)) {
      for (int j = 2; j < n; j++) {
        if (provjera_prost(j))
          if (n == i + j) {
            p = i;
            q = j;
            return;
          }
      }
    }
  }
  throw std::logic_error("Rastava ne postoji");
}
int main() {
  std::cout << "Unesi broj: ";
  int n, p = 0, q = 0;
  std::cin >> n;

  clock_t vrijeme1 = clock();
  Goldbach(n, p, q);
  clock_t vrijeme2 = clock();
  int ukvrijeme = (vrijeme2 - vrijeme1) / (CLOCKS_PER_SEC / 1000);
  std::cout << "\nVrijeme izvrsenja: " << ukvrijeme << " ms." << std::endl;
  return 0;
}