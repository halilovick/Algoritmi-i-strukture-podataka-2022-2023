#include <iostream>

bool permutacija(std::string s1, std::string s2) {
  bool ima = false;
  for (int i = 0; i < s1.length(); i++) {
    for (int j = 0; j < s2.length(); j++) {
      if (s1[i] == s2[j])
        ima = true;
    }
    if (ima == false)
      return false;
    ima = false;
  }
  return true;
}

int main() {
  std::string s1("emir"), s2("kerim");
  std::cout << permutacija(s1, s2);
}