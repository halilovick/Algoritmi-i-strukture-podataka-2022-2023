#include <ctime>
#include <iostream>

bool prost(int x) {
  if ((x % 2 == 0 && x != 2) || x < 2)
    return false;
  for (int i = 3; i < x; i++) {
    if (x % i == 0)
      return false;
  }
  return true;
}
void Goldbach(int n, int &p, int &q) {
  if (n <= 2 || (n % 2 == 1 && !prost(n - 2)))
    throw std::logic_error("Rastava ne postoji");
  for (int i = 2; i <= n / 2; i++) {
    if (prost(i) && prost(n - i)) {
      p = i;
      q = n - i;
      return;
    }
  }
  throw std::logic_error("Rastava ne postoji");
}
int main() {
  int broj;
  std::cout << "Unesi broj: ";
  std::cin >> broj;
  int prvi = 0, drugi = 0;
  try {
    clock_t vrijeme1 = clock();
    Goldbach(broj, prvi, drugi);
    clock_t vrijeme2 = clock();
    int ukvrijeme = (vrijeme2 - vrijeme1) / (CLOCKS_PER_SEC / 1000);
    std::cout << "Vrijeme izvrsenja: " << ukvrijeme << " ms." << std::endl;
    std::cout << broj << " je zbir prostih brojeva " << prvi << " i " << drugi;
  } catch (...) {
    std::cout << broj << " nije zbir dva prosta broja!";
  }
  return 0;
}